<?php

// Instruccion de impresion de informacion
echo "hola buenas tardes";

/*
Comentario largo:
 
*/

print_r("hola muy buenas tardes");

print("hola buenas")

 ?>