<?php

// Ciclo for

for ($numeroInicial=0; $numeroInicial<18; $numeroInicial++ ){

    echo "Numero ".$numeroInicial."<br/>"; 
}



?>