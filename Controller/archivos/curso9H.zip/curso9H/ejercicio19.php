<?php

$nombre="Oscar Uh";
$nombreMayusculas= strtoupper($nombre);

echo $nombreMayusculas;

?>
