<?php

$numeroIncial=0;

do{

    echo "Numero".$numeroInicial."<br/>";
    $numeroInicial++;

}while($numeroInicial<=10)

?>