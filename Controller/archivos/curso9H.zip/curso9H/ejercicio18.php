<?php

$numeroAleatorio= rand(1,10);

echo $numeroAleatorio;

?>