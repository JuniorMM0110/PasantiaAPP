<?php

if($_GET){

    $nombre=$_GET['nombre'];

    echo "hola " . $nombre;
}

?>