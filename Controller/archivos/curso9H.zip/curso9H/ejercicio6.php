<?php

    $Edad=32; //Entero
    
    $Nombre="Oscar"; // String

    $Altura=1.4; // Flotante o decimal

    $Programador=null; // Valor nulo

    echo "El nombre es ".$Nombre." la edad es ".$Altura." el puesto ".$Programador;





?>