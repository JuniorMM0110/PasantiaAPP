<?php

function imprimirNombre($nombre,$apellido=""){
    // Rutinas (instrucciones)
    echo "Hola ".$nombre." ".$apellido." <br/>";

}
// Llamar a la funcion
imprimirNombre("Oscar");
imprimirNombre("Pedro","Perez");
imprimirNombre("maria","Martinez");

?>