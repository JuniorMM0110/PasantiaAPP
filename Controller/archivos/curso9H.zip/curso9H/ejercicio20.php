<?php 

$hoy= date("Y / m / d");


echo $hoy;

?>