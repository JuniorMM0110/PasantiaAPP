<?php

$nummeroInicial=0;

while($nummeroInicial<10){

    echo "Numero ".$nummeroInicial."<br/>";
    $nummeroInicial++;
}

?>