<?php 

    $edad=32;// variables

    echo $edad."<br/>";

    $edad = 40; // cambiar valor de la variable

    echo $edad;

    // uso de constantes
    define("NOMBRE","OSCAR");

    // imprimir constante
    echo NOMBRE;


?>